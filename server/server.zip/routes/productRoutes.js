const express = require('express');
const router = express.Router();
const upload = require('../middlewares/uploadMiddleware');
const { protect, admin } = require('../middlewares/authMiddleware');
const {
  createProduct, updateProduct, deleteProduct,
  getProductById, getProducts, addReview
} = require('../controllers/productController');

router.get('/', getProducts);
router.post('/', protect, admin, upload.array('images', 5), createProduct);
router.get('/:id', getProductById);
router.put('/:id', protect, admin, upload.array('images', 5), updateProduct);
router.delete('/:id', protect, admin, deleteProduct);
router.post('/:id/reviews', protect, addReview);

module.exports = router;
