const asyncHandler = require('express-async-handler');
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');

// POST /api/orders - create order from cart
const createOrder = asyncHandler(async (req, res) => {
  const { shippingAddress, paymentMethod } = req.body;
  const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');
  if(!cart || cart.items.length === 0) { res.status(400); throw new Error('Cart empty'); }

  const itemsPrice = cart.items.reduce((acc, it) => acc + it.product.price * it.qty, 0);
  const taxPrice = +(itemsPrice * 0.05).toFixed(2);
  const shippingPrice = itemsPrice > 500 ? 0 : 50;
  const totalPrice = + (itemsPrice + taxPrice + shippingPrice).toFixed(2);

  const order = new Order({
    user: req.user._id,
    orderItems: cart.items.map(it => ({
      product: it.product._id,
      title: it.product.title,
      qty: it.qty,
      price: it.product.price,
      image: it.product.images[0]?.url || ''
    })),
    shippingAddress,
    paymentMethod,
    itemsPrice,
    taxPrice,
    shippingPrice,
    totalPrice,
    isPaid: paymentMethod !== 'dummy' ? true : false,
    paidAt: paymentMethod !== 'dummy' ? Date.now() : null
  });
  const created = await order.save();

  // reduce stock
  for (const it of cart.items) {
    const p = await Product.findById(it.product._id);
    if(p) {
      p.stock = Math.max(0, p.stock - it.qty);
      await p.save();
    }
  }

  // empty cart
  cart.items = [];
  await cart.save();

  res.status(201).json(created);
});

// GET /api/orders/myorders
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json(orders);
});

// GET /api/orders/:id
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('user', 'name email');
  if(!order) { res.status(404); throw new Error('Order not found'); }
  res.json(order);
});

// PUT /api/orders/:id/status (admin) - update status
const updateOrderStatus = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if(!order) { res.status(404); throw new Error('Order not found'); }
  order.status = req.body.status || order.status;
  if(order.status === 'delivered') order.deliveredAt = Date.now();
  await order.save();
  res.json(order);
});

module.exports = { createOrder, getMyOrders, getOrderById, updateOrderStatus };
