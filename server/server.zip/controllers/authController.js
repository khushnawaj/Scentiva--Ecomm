const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const crypto = require('crypto');

// @desc register user
// POST /api/auth/register
const registerUser = asyncHandler( async (req, res) => {
  const { name, email, password } = req.body;
  const userExists = await User.findOne({ email });
  if(userExists){
    res.status(400);
    throw new Error('User already exists');
  }
  const user = await User.create({ name, email, password });
  if(user) {
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user)
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
});

// @desc login user
// POST /api/auth/login
const authUser = asyncHandler( async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if(user && (await user.matchPassword(password))){
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user)
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});

// @desc forgot password (dummy implementation)
// POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  if(!user) {
    res.status(404); throw new Error('No user with that email');
  }
  const resetToken = crypto.randomBytes(20).toString('hex');
  res.json({ message: 'Password reset token (demo)', resetToken });
});

// @desc get profile
// GET /api/auth/profile
const getProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('-password');
  res.json(user);
});

// @desc update profile
// PUT /api/auth/profile
const updateProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if(user) {
    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;
    if(req.body.password) user.password = req.body.password;
    if(req.body.addresses) user.addresses = req.body.addresses || user.addresses;
    const updated = await user.save();
    res.json({
      _id: updated._id,
      name: updated.name,
      email: updated.email,
      token: generateToken(updated)
    });
  } else {
    res.status(404); throw new Error('User not found');
  }
});

module.exports = { registerUser, authUser, forgotPassword, getProfile, updateProfile };
