const asyncHandler = require('express-async-handler');
const Product = require('../models/Product');
const Review = require('../models/Review');
const mongoose = require('mongoose');

// @desc Create product (admin)
// POST /api/products
const createProduct = asyncHandler(async (req, res) => {
  const { title, description, price, discountPrice, category, brand, stock } = req.body;
  const images = (req.files || []).map(f => ({ url: `/uploads/${f.filename}` }));
  const product = new Product({ title, description, price, discountPrice, category, brand, stock, images });
  const created = await product.save();
  res.status(201).json(created);
});

// @desc Update product (admin)
// PUT /api/products/:id
const updateProduct = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if(!mongoose.Types.ObjectId.isValid(id)) { res.status(400); throw new Error('Invalid id'); }
  const product = await Product.findById(id);
  if(!product) { res.status(404); throw new Error('Product not found'); }
  const updates = req.body;
  if(req.files && req.files.length) {
    product.images = (req.files || []).map(f => ({ url: `/uploads/${f.filename}` }));
  }
  Object.assign(product, updates);
  const saved = await product.save();
  res.json(saved);
});

// @desc Delete product (admin)
// DELETE /api/products/:id
const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if(!product) { res.status(404); throw new Error('Product not found'); }
  await product.remove();
  res.json({ message: 'Product removed' });
});

// @desc Get product by id
// GET /api/products/:id
const getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id).populate({
    path: 'reviews',
    populate: { path: 'user', select: 'name' }
  });
  if(product) res.json(product);
  else { res.status(404); throw new Error('Product not found'); }
});

// @desc Get products list with search, filter, sort, pagination
// GET /api/products
const getProducts = asyncHandler(async (req, res) => {
  let { page = 1, limit = 12, keyword = '', category, minPrice, maxPrice, sort } = req.query;
  page = Number(page); limit = Number(limit);
  const query = {};
  if(keyword) query.$text = { $search: keyword };
  if(category) query.category = category;
  if(minPrice || maxPrice) query.price = {};
  if(minPrice) query.price.$gte = Number(minPrice);
  if(maxPrice) query.price.$lte = Number(maxPrice);

  let cursor = Product.find(query).populate('category');

  // sort
  if(sort === 'newest') cursor = cursor.sort({ createdAt: -1 });
  if(sort === 'priceAsc') cursor = cursor.sort({ price: 1 });
  if(sort === 'priceDesc') cursor = cursor.sort({ price: -1 });
  if(sort === 'rating') cursor = cursor.sort({ rating: -1 });

  const total = await Product.countDocuments(query);
  const products = await cursor.skip((page-1)*limit).limit(limit);
  res.json({ products, page, pages: Math.ceil(total/limit), total });
});

// @desc Add review
// POST /api/products/:id/reviews
const addReview = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if(!product) { res.status(404); throw new Error('Product not found'); }

  const { rating, comment } = req.body;
  // check if user already reviewed
  const existing = await Review.findOne({ user: req.user._id, product: product._id });
  if(existing) { res.status(400); throw new Error('Product already reviewed'); }

  const review = new Review({
    user: req.user._id,
    product: product._id,
    rating: Number(rating),
    comment
  });
  await review.save();

  product.reviews.push(review._id);
  product.numReviews = product.reviews.length;
  const reviews = await Review.find({ product: product._id });
  product.rating = reviews.reduce((acc, r) => acc + r.rating, 0) / (reviews.length || 1);
  await product.save();

  res.status(201).json({ message: 'Review added' });
});

module.exports = {
  createProduct, updateProduct, deleteProduct, getProductById, getProducts, addReview
};
